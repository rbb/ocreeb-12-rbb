# Psion Keyboards

Keyboard from an old [Psion Series 5mx](https://en.wikipedia.org/wiki/Psion_Series_5) handheld computer, driven by a custom RP2040 adapter.

Currently supported layouts:

- UK (default)
- Swedish/Nordic
